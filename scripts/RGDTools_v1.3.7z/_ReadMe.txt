AUTHOR: Copernicus aka cope
CONTACT: Try ModDB
GAME: Company of Heroes 2/Company of Heroes/DoW3/other titles using RGDs
DESCRIPTION: Converter for RGD to Text/XML/JSON
VERSION: 1.3

Table of Contents:
1. Installation
2. Usage rgdConv
3. Changelog

------------------------------

1. Installation:

YOU NEED .NET FRAMEWORK 4.6 TO USE THIS TOOL.

Place the included files in any folder of your choice.

------------------------------

2. Usage rgdConv:

rgdConv converts between CoH2/DoW3-RGDs and a text-based format (or XML). It can also convert to JSON, but not the other way around since that conversion is lossy.

Usage: rgdConv.exe <hashdict> <inputdir> <outputdir> [-x|-j] [-r|-t] [-d]
 -x   convert to/from XML instead of text
 -j   convert RGDs to JSON (no JSON to RGD available)
 -r   convert RGDs to text (/XML)
 -t   convert text (/XML) to RGD
 -d   use DoW3 RGD format
 
If none of the above is specified, both conversions will be applied
If it encounters any unknown hash values during the conversion, it will create a file called 'unknown_hashes.txt' listing them.

Usage example:

Convert all RGDs in subfolders of 'input' to text and store them in the 'output' folder (if the RGDs use DoW3's format, this is automatically detected in this step).
rgdConv.exe hash_dict.txt input output -r

Convert all TXTs in subfolders of 'original' to RGD using DoW3's format and store them in the 'modded' folder:
rgdConv.exe hash_dict.txt original modded -t -d

------------------------------

3. Changelog:

V1.3 - 04/30/17
- added support for DoW3 RGDs

V1.2a - 04/22/13
- added support for JSON output

V1.2 - 04/21/13
- fixed a bug with produced RGDs

V1.1 - 12/19/12
- added rgdCrawl
- rgdConv now also outputs the file containing the unknown hash for every unknown hash
- added more hashes (60+)

DONE.