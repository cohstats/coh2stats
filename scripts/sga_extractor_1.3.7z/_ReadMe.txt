AUTHOR: Copernicus aka cope
CONTACT: Try ModDB
GAME: Company of Heroes 2 / DoW3
DESCRIPTION: SGA Extractor for CoH2 / DoW3
VERSION: Release
DATE: 29/04/2017

Table of Contents:
1. Installation
2. Usage cc2sga
3. Changelog

------------------------------

1. Installation:

YOU NEED .NET FRAMEWORK 4.0 TO USE THIS TOOL.

Place the included files in any folder of your choice.

------------------------------

2. Usage:

cc2sga.exe <sga_file> [destination]

If no destination is provided, a new folder with the name of the SGA archive will be created.

------------------------------

3. Changelog

29/04/2017
Added support for SGAv9.

26/09/2013
Added support for SGAv7.

DONE.